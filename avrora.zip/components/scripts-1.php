<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="../libs/wow/wow.min.js"></script>
<script src="../js/main.js?v=20" type="text/javascript" charset="utf-8"></script>