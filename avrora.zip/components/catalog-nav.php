<div class="catalog__nav-wrapper">
    <nav class="catalog__nav">
        <a class="catalog__nav-link" href="../catalog/category-1.php">Кухни</a>
        <a class="catalog__nav-link" href="../catalog/category-2.php">Шкафы-купе</a>
        <a class="catalog__nav-link" href="../catalog/category-3.php">Гардеробные</a>
        <a class="catalog__nav-link" href="../catalog/category-4.php">Шкафы распашные</a>
        <a class="catalog__nav-link" href="../catalog/category-5.php">Прихожие</a>
        <a class="catalog__nav-link" href="../catalog/category-6.php">Шкафы угловые</a>
    </nav>
</div>    